# Modules are the specific files containing code that perform specific task.
# They are the pre built classes that help you to perform various operation. ex. Datetime


# function to calculate in the module
def add(a,b):
    return (a+b)

def multi(a,b):
    return (a*b)

def greet(name):
    return f"Hello, {name}!"
