#  Use the random module to simulate a dice roll.

import random

dice_roll = random.randint(1, 6)

print("The result of the dice roll is::",dice_roll)

print("\n")
print("------------------------------------")
# Use the math module to calculate the square root of a number. 
import math

number = int(input("Enter a number::"))

srt = math.sqrt(number)

print(f"The square root of {number} is:", srt)



