num = [10, 55, 85, 7, 73, 23]

average = sum(num)/len(num)

print("Average of the number is >>",average)