# Sort a list of strings alphabetically

li = ["Geography", "Polity", "History", "Economy","Art & Culture"]

sort = sorted(li)

print("Sorted List >>",sort)