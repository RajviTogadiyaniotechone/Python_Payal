# Create a while loop that sums numbers from 1 to 10. 

i = 1;
sum = 0;

while i <= 10:
    sum += i;
    i = i+1;

print("sums numbers from 1 to 10 is >> ",sum)