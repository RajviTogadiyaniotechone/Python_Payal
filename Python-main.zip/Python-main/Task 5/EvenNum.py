# Write a for loop that prints even numbers from 1 to 100. 

for i in range(0, 101):
    if i % 2 == 0:
        print(i, end=",");
   