def sort_string(s):
    ls = sorted(s)
    ans = ''.join(ls)
    return ans

print(sort_string("payal"))