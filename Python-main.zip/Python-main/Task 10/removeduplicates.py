# Write a program that removes duplicates from a list using sets. 

l = [1, 2, 3, 4, 5, 5, 3, 1, 7]

ans = list(set(l))

print("After a remove duplicates the values are>>",ans)

