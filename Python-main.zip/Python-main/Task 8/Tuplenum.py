# Create a tuple of three numbers and print the second element. 

tup = 10, 20, 30
print(tup)
print(type(tup))

print("Second element of the tuple is>>",tup[1])