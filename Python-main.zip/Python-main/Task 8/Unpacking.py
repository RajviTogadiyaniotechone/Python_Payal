# Write a program to unpack a tuple into multiple variables

t1 = ("India", "USA", "Canada", "Singapore")

print(t1)

a, b, c, d = t1

print(a)

print(b)

print(c)

print(d)
