fp = open('D:\Payal Ramani\Date2.txt', 'r')

print(fp.read())

fp.close()