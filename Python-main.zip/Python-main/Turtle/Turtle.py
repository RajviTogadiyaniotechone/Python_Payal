import turtle as t
from random import random

for i in range(4):
    t.forward(50)
    t.right(90)
t.done()