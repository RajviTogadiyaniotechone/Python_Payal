# Write a program to check if a number is positive, negative, or zero

number = int(input("Enter Number: "));

if number > 0:
    print(number,"is Positive Number");
elif number < 0:
   print(number,"is Negative Number");
else:
    print("Number is 0");