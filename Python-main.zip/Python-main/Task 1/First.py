# Print "Hello, World!" and test Python installation
first = "Hello Python";

print(first)
print("arrays of string>>",first[1]);
print("Lenght of the string>>",len(first))
a = first.capitalize();
b = first.split();

print("a is capitalize the first word::",a);
print("b is split the string::",b);

txt = "The best things in life are free!"
print("free" in txt);

if "free" in txt:
    print("Yes, 'free' is present");

#string slicing
print("String Slicing>>",first[2:5]);
print(first.upper());

print(20 > 40);
print(bool("false"));

# Write a Python program that prints your name

print("Payal Ramani");